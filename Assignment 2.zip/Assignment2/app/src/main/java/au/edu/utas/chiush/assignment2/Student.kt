package au.edu.utas.chiush.assignment2

class Student (
        var id: String? =  null,

        var studentName: String? = null,
        var studentID: String? = null,
        var WeeksMark: Map<Int,Int>? = null,
        var imageURL: String? = null,
        var checkBol: Boolean? = null
)